// window.onload = function () {

    
//     if (chrome.devtools) {
//         var command = '$A.PerfDevTools.getComponentCreationProfile()';
//         chrome.devtools.inspectedWindow.eval(command, function (payload, exception) {
//             new AuraPerfPanel(payload, "flamechart");
//         });
//     }
// };

